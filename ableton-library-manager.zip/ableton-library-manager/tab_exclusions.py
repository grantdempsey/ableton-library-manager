# tab_exclusions.py - Piece 1: Framework Imports & Configuration Synchronization
import tkinter as tk
from tkinter import ttk, messagebox
import os
import json
import gui_theme
import sorter_engine

class ExclusionsTab(ttk.Frame):
    def __init__(self, parent):
        """Initializes the folder tracking block ignore rule dashboard array."""
        super().__init__(parent)
        
        self.resolved_backend_key = "IGNORED_DIRECTORIES"
        self.active_exclusions_set = set()
        
        # Pull configurations and align memory slots
        self.synchronize_backend_variables()

        self.setup_ui_layout()
        self.refresh_exclusion_list()

    def synchronize_backend_variables(self):
        """Forces the backend config loader to run and maps IGNORED_DIRECTORIES into UI memory."""
        if hasattr(sorter_engine, 'load_external_config'):
            try:
                sorter_engine.load_external_config()
            except Exception:
                pass

        if hasattr(sorter_engine, 'IGNORED_DIRECTORIES'):
            raw_val = sorter_engine.IGNORED_DIRECTORIES
            if isinstance(raw_val, (list, set)):
                self.active_exclusions_set = set(raw_val)

        # 🌟 CORE DEFENSIVE AUTOMATION:
        # Guarantees unpitched loop containers are protected right out of the box
        if "No Key Info" not in self.active_exclusions_set:
            self.active_exclusions_set.add("No Key Info")

        self.flush_changes_to_backend_memory()

    def flush_changes_to_backend_memory(self):
        """Mirrors UI sets back into engine arrays and flushes parameters onto local disk configuration JSON layers."""
        setattr(sorter_engine, 'IGNORED_DIRECTORIES', sorted(list(self.active_exclusions_set)))

        config_path = getattr(sorter_engine, 'CONFIG_FILE', 'library_config.json')
        try:
            disk_data = {}
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    disk_data = json.load(f)
            
            disk_data['IGNORED_DIRECTORIES'] = sorted(list(self.active_exclusions_set))
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(disk_data, f, indent=4)
                
            if hasattr(sorter_engine, 'load_external_config'):
                sorter_engine.load_external_config()
        except Exception:
            pass

    def setup_ui_layout(self):
        """Draws the simplified high-fidelity exclusion panels with all headers stripped down."""
        t = gui_theme.THEME

        # 1. Main Simplified Title Header
        header_lbl = ttk.Label(self, text="Folder Exclusions", font=("Segoe UI", 12, "bold"))
        header_lbl.pack(anchor="w", padx=15, pady=15)

        # 2. INPUT SELECTION TRAY
        input_group = ttk.LabelFrame(self, text=" Add Folder to Skip ")
        input_group.pack(fill="x", padx=15, pady=10, ipady=5)

        f_row = tk.Frame(input_group, bg=t["bg_dark"])
        f_row.pack(fill="x", padx=15, pady=8)

        self.ent_pattern = tk.Entry(f_row, font=("Consolas", 10), bg=t["bg_field"], fg=t["fg_light"], bd=1, relief="solid", insertbackground=t["fg_light"])
        self.ent_pattern.pack(side="left", fill="x", expand=True, ipady=3, padx=(0, 10))
        self.ent_pattern.bind("<Return>", lambda e: self.add_exclusion_pattern())

        btn_add = tk.Button(
            f_row, text="+ Append Block", font=("Segoe UI", 9, "bold"),
            bg=t["btn_execute"], fg="white", activebackground="#0e6b36", activeforeground="white",
            bd=0, padx=20, command=self.add_exclusion_pattern
        )
        btn_add.pack(side="right")

        # 3. INSULATED STYLE CONFIGURATION
        try:
            style = ttk.Style(self.master)
            style.configure("Exclusions.Treeview", background=t["bg_field"], foreground=t["fg_light"], fieldbackground=t["bg_field"], rowheight=24, font=("Segoe UI", 9))
            
            # Hide the table header completely by setting its font sizing constraints to zero
            style.configure("Exclusions.Treeview.Heading", background=t["bg_panel"], foreground=t["bg_panel"], font=("Segoe UI", 0, "bold"), rowheight=0)
            
            style.map("Exclusions.Treeview",
                background=[("selected", t["hover_dark"]), ("active", t["bg_field"])],
                foreground=[("selected", t["accent_neon"]), ("active", t["fg_light"])]
            )
        except Exception:
            pass

        # tab_exclusions.py - Piece 3: Treeview Generation Elements
        t = gui_theme.THEME

        # 4. ENTRY LISTING TABLE WINDOW DISPLAY CONTAINER
        grid_group = ttk.LabelFrame(self, text=" Folders Currently Skipped ")
        grid_group.pack(fill="both", expand=True, padx=15, pady=10)

        f_tree_frame = tk.Frame(grid_group, bg=t["bg_field"], bd=1, relief="solid")
        f_tree_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Using show="tree" instead of show="headings" entirely deletes the text header row block completely
        self.tree = ttk.Treeview(f_tree_frame, columns=("pattern",), show="tree", style="Exclusions.Treeview", selectmode="browse")
        
        self.tree.column("#0", width=0, minwidth=0, stretch=False) # Strip out native padding column channel
        self.tree.column("pattern", stretch=True, anchor="w", minwidth=300)
        self.tree.pack(side="left", fill="both", expand=True)

        scroll = ttk.Scrollbar(f_tree_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.config(yscrollcommand=scroll.set)

        # 5. PURGE SELECTION FOOTER WITH CONFIRMATION TETHER
        f_footer = tk.Frame(self, bg=t["bg_dark"])
        f_footer.pack(fill="x", side="bottom", padx=15, pady=15)

        btn_drop = tk.Button(
            f_footer, text="❌ Purge Selection", font=("Segoe UI", 9, "bold"),
            bg=t["bg_panel"], fg=t["fg_light"], activebackground="#ff3333", activeforeground="white",
            bd=1, relief="solid", padx=15, pady=5, command=self.remove_exclusion_pattern
        )
        btn_drop.pack(side="left")
        
        self.focus_set()

    def refresh_exclusion_list(self):
        """Wipes and re-populates active registry logs into layout grids accurately."""
        self.tree.delete(*self.tree.get_children())
        if self.active_exclusions_set:
            try:
                for item in sorted(list(self.active_exclusions_set)):
                    if item:
                        self.tree.insert("", tk.END, values=(item,))
            except Exception:
                pass

    def add_exclusion_pattern(self):
        token = self.ent_pattern.get().strip()
        if not token:
            messagebox.showwarning("Validation Error", "Exclusion token matching string field cannot be blank.")
            return
            
        if token in self.active_exclusions_set:
            messagebox.showinfo("Ignored Duplicated Pattern", "Specified exclusion path string pattern is already active.")
            return
            
        self.active_exclusions_set.add(token)
        self.flush_changes_to_backend_memory()
        self.refresh_exclusion_list()
        self.ent_pattern.delete(0, tk.END)

    def remove_exclusion_pattern(self):
        """Removes a chosen directory pattern from backend rules with an active safety verification gate."""
        selected_target = self.tree.selection()
        if not selected_target:
            messagebox.showwarning("Selection Error", "Please highlight a target exclusion layout line to drop.")
            return
            
        values = self.tree.item(selected_target, "values")
        if values and len(values) > 0:
            actual_token = values[0]
            
            # 🚨 BASELINE SAFETY SYSTEM INTENT EXCLUSION:
            # Prevents you from accidentally removing core engine layout protection routes
            if actual_token == "No Key Info":
                messagebox.showerror(
                    "Permission Denied", 
                    "The 'No Key Info' rule is a hardcoded baseline guard pattern designed to prevent unpitched sample packing loops.\n\n"
                    "It cannot be purged from the active global storage ignore configurations layer.",
                    parent=self.nametowidget(".")
                )
                return
            
            confirm_purge = messagebox.askyesno(
                "Verify Exclusion Removal", 
                f"Are you sure you want to restore '{actual_token}' to active sorting scanning sweeps?\n\n"
                "This path layout will no longer be skipped during optimization checks.",
                icon="warning"
            )
            
            if confirm_purge:
                if actual_token in self.active_exclusions_set:
                    self.active_exclusions_set.remove(actual_token)
                    self.flush_changes_to_backend_memory()
                    self.refresh_exclusion_list()
