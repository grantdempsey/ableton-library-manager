# tab_matrix.py - Core Automation Logic, Profile Portability Engines & Layout Matrix Assemblies
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import re
import os
import json
import datetime
import sorter_engine
import gui_theme
import webbrowser

_drum_tree = None
_synth_tree = None
_status_label_ref = None

def refresh_matrix_data():
    """Distributes dictionary rule matrices out cleanly to their respective table grids."""
    if _drum_tree is not None:
        _drum_tree.delete(*_drum_tree.get_children())
        for pat, fld in sorter_engine.DRUM_KEYWORDS.items():
            _drum_tree.insert('', 'end', values=(pat, fld))
            
    if _synth_tree is not None:
        _synth_tree.delete(*_synth_tree.get_children())
        for pat, fld in sorter_engine.SYNTH_EXTS.items():
            _synth_tree.insert('', 'end', values=(pat, fld))
        for pat, fld in sorter_engine.NATIVE_EXTS.items():
            _synth_tree.insert('', 'end', values=(pat, fld))

def _sync_config_state(status_msg):
    """Safely dumps data mappings down onto physical local config file layouts."""
    try:
        disk_data = {}
        if os.path.exists(sorter_engine.CONFIG_FILE):
            with open(sorter_engine.CONFIG_FILE, 'r', encoding='utf-8') as f:
                disk_data = json.load(f)
        
        disk_data["DRUM_KEYWORDS"] = sorter_engine.DRUM_KEYWORDS
        disk_data["SYNTH_EXTS"] = sorter_engine.SYNTH_EXTS
        disk_data["NATIVE_EXTS"] = sorter_engine.NATIVE_EXTS
        
        if hasattr(sorter_engine, 'IGNORED_DIRECTORIES'):
            disk_data["IGNORED_DIRECTORIES"] = sorter_engine.IGNORED_DIRECTORIES
            
        with open(sorter_engine.CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(disk_data, f, indent=4)
            
        sorter_engine.load_external_config()
        refresh_matrix_data()
        if _status_label_ref:
            _status_label_ref.config(text=f" Application Status: {status_msg}", fg=gui_theme.THEME["accent_neon"])
    except Exception as e:
        messagebox.showerror("Sync Failure", f"Could not commit parameters script: {str(e)}")

# tab_matrix.py - Piece 2: Workspace Serialization Portability Engines (Import/Export)
def execute_profile_json_export(parent_window):
    """Packages and dumps custom studio sorting dictionaries directly inside the User Library."""
    # 🌟 FIXED CROSS-PLATFORM ROUTING: Dynamically tracks studio paths to stay immune to Mac tracebacks
    user_library_default_route = gui_theme.USER_LIBRARY_PATH
    
    target_filepath = filedialog.asksaveasfilename(
        title="Export Studio Workspace Profile JSON",
        initialdir=user_library_default_route if os.path.exists(user_library_default_route) else None,
        initialfile="ableton_studio_profile.json",
        defaultextension=".json",
        filetypes=[("JSON Profile Configurations", "*.json")]
    )
    if not target_filepath:
        return

    try:
        profile_package = {
            "profile_identity": "AFC_Production_Workspace",
            "export_timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "DRUM_KEYWORDS": sorter_engine.DRUM_KEYWORDS,
            "SYNTH_EXTS": sorter_engine.SYNTH_EXTS,
            "NATIVE_EXTS": sorter_engine.NATIVE_EXTS,
            "IGNORED_DIRECTORIES": getattr(sorter_engine, 'IGNORED_DIRECTORIES', ["No Key Info"])
        }
        
        with open(target_filepath, 'w', encoding='utf-8') as f:
            json.dump(profile_package, f, indent=4)
            
        if _status_label_ref:
            _status_label_ref.config(text=" Application Status: Studio configuration profile exported cleanly!", fg=gui_theme.THEME["accent_gold"])
        messagebox.showinfo("Export Successful", f"Workspace taxonomy definitions logged to location:\n{os.path.basename(target_filepath)}")
    except Exception as e:
        messagebox.showerror("Export Failed", f"Could not package profile file system tracks: {str(e)}")

def execute_profile_json_import(parent_window):
    """Ingests external configuration profiles directly out of the User Library to restore rule parameters."""
    # 🌟 FIXED CROSS-PLATFORM ROUTING: Dynamically tracks studio paths to stay immune to Mac tracebacks
    user_library_default_route = gui_theme.USER_LIBRARY_PATH
    
    target_filepath = filedialog.askopenfilename(
        title="Import Studio Workspace Profile JSON",
        initialdir=user_library_default_route if os.path.exists(user_library_default_route) else None,
        filetypes=[("JSON Profile Configurations", "*.json")]
    )
    if not target_filepath:
        return

    try:
        with open(target_filepath, 'r', encoding='utf-8') as f:
            imported_package = json.load(f)

        if not any(k in imported_package for k in ["DRUM_KEYWORDS", "SYNTH_EXTS", "NATIVE_EXTS"]):
            messagebox.showerror("Parsing Failure", "Selected file lacks valid rule matrix dictionaries or pattern fields.")
            return

        confirm_overwrite = messagebox.askyesno(
            "Confirm Workspace Import",
            "Importing this profile will merge or overwrite your current taxonomy rules.\n\n"
            "Do you want to proceed with rule array synchronization?",
            icon="warning"
        )
        if not confirm_overwrite:
            return

        if "DRUM_KEYWORDS" in imported_package:
            sorter_engine.DRUM_KEYWORDS.update(imported_package["DRUM_KEYWORDS"])
        if "SYNTH_EXTS" in imported_package:
            sorter_engine.SYNTH_EXTS.update(imported_package["SYNTH_EXTS"])
        if "NATIVE_EXTS" in imported_package:
            sorter_engine.NATIVE_EXTS.update(imported_package["NATIVE_EXTS"])
        if "IGNORED_DIRECTORIES" in imported_package:
            current_ignored = set(getattr(sorter_engine, 'IGNORED_DIRECTORIES', []))
            current_ignored.update(imported_package["IGNORED_DIRECTORIES"])
            setattr(sorter_engine, 'IGNORED_DIRECTORIES', sorted(list(current_ignored)))

        _sync_config_state("Workspace parameters reconstructed and synchronized clean!")
        messagebox.showinfo("Import Complete", "Studio profile ingested successfully! Grid ledgers updated.")
    except Exception as e:
        messagebox.showerror("Import Failed", f"Could not ingest configuration script data: {str(e)}")

# Function 1: Window Generation and Geometry Target Anchoring
def launch_interactive_rule_builder(parent_win):
    """Spawns an interactive custom expression template generation dialog popup."""
    popup = tk.Toplevel(parent_win)
    popup.title("Create New Sorting Rule Wizard")
    popup.geometry("540x440")
    popup.resizable(False, False)
    popup.configure(bg=gui_theme.THEME["bg_dark"])
    popup.grab_set()

    # Calculate system display geometry states to center the canvas accurately
    popup.update_idletasks()
    master_top = parent_win.winfo_toplevel()
    target_x = master_top.winfo_x() + int((master_top.winfo_width() - 540) / 2)
    target_y = master_top.winfo_y() + int((master_top.winfo_height() - 440) / 2)
    popup.geometry(f"540x440+{target_x}+{target_y}")

    # Initialize tracking variables for custom user entry overrides
    var_custom_regex = tk.BooleanVar(value=False)
    var_user_typed_folder = tk.BooleanVar(value=False)

    tk.Label(
        popup, text="Fill in the blanks to build your sorting rule:", 
        font=("Segoe UI", 10, "bold"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"]
    ).pack(anchor="w", padx=20, pady=(20, 10))

    # Hand off window configurations down to individual field builders
    build_rule_input_matrix_fields(popup, var_custom_regex, var_user_typed_folder)

# Function 2: UI Form Construction and Component Generation Triggers
def build_rule_input_matrix_fields(popup, var_custom_regex, var_user_typed_folder):
    """Assembles layout forms and connects dynamic input elements to tracking loops."""
    f_conv = tk.Frame(popup, bg=gui_theme.THEME["bg_dark"])
    f_conv.pack(fill="x", padx=20, pady=5)

    lbl_prefix = tk.Label(f_conv, text="When file name contains the word:", font=("Segoe UI", 9), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"])
    lbl_prefix.grid(row=0, column=0, sticky="w", pady=6)
    
    ent_token = tk.Entry(f_conv, font=("Segoe UI", 9), bg=gui_theme.THEME["bg_field"], fg=gui_theme.THEME["fg_light"], insertbackground=gui_theme.THEME["fg_light"], bd=1, relief="solid", width=22)
    ent_token.grid(row=0, column=1, padx=8, sticky="w")
    ent_token.insert(0, "snare")

    tk.Label(f_conv, text="Move it into a subfolder named:", font=("Segoe UI", 9), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"]).grid(row=1, column=0, sticky="w", pady=6)
    
    f_folder_input = tk.Frame(f_conv, bg=gui_theme.THEME["bg_dark"])
    f_folder_input.grid(row=1, column=1, padx=8, sticky="w")
    
    ent_fld = tk.Entry(f_folder_input, font=("Segoe UI", 9), bg=gui_theme.THEME["bg_field"], fg=gui_theme.THEME["fg_light"], insertbackground=gui_theme.THEME["fg_light"], bd=1, relief="solid", width=22)
    ent_fld.pack(side="left")
    ent_fld.insert(0, "Snares")

    lbl_hint = tk.Label(f_folder_input, text="(or type custom name)", font=("Segoe UI", 8, "italic"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_muted"])
    lbl_hint.pack(side="left", padx=6)

    # Wipe descriptive auto-text guides upon detecting immediate typing overrides
    ent_fld.bind("<Key>", lambda e: [var_user_typed_folder.set(True), lbl_hint.pack_forget()])

    tk.Label(f_conv, text="✨ Add to an existing sorting folder:", font=("Segoe UI", 9), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"]).grid(row=2, column=0, sticky="w", pady=(14, 2))
    
    cb_existing = ttk.Combobox(f_conv, font=("Segoe UI", 9), state="readonly", width=20)
    existing_folders = sorted(list(set(sorter_engine.DRUM_KEYWORDS.values())))
    cb_existing['values'] = ["-- Select Active Folder --"] + existing_folders
    cb_existing.current(0)
    cb_existing.grid(row=2, column=1, padx=8, pady=(14, 2), sticky="w")

    # Forward configurations down to structural display calculators
    assemble_formula_preview_blocks(popup, f_conv, ent_token, ent_fld, cb_existing, lbl_prefix, lbl_hint, var_custom_regex, var_user_typed_folder)

# Function 3: Text Formula Analyzers and Live Validation Loops
def assemble_formula_preview_blocks(popup, f_conv, ent_token, ent_fld, cb_existing, lbl_prefix, lbl_hint, var_custom_regex, var_user_typed_folder):
    """Sets up the live regex code syntax visualizer block and links variable bindings."""
    f_toggle = tk.Frame(popup, bg=gui_theme.THEME["bg_dark"])
    f_toggle.pack(fill="x", padx=20, pady=(15, 0))

    lbl_preview_title = tk.Label(popup, text="Generated System Matching Formula Code:", font=("Segoe UI", 9, "bold"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"])
    lbl_preview_title.pack(anchor="w", padx=20, pady=(15, 2))

    f_viz = tk.Frame(popup, bg=gui_theme.THEME["bg_field"], bd=1, relief="solid")
    f_viz.pack(fill="x", padx=20, pady=4)

    lbl_formula = tk.Label(f_viz, text="", font=("Consolas", 10, "bold"), bg=gui_theme.THEME["bg_field"], fg=gui_theme.THEME["accent_neon"], padx=10, pady=10, anchor="w")
    lbl_formula.pack(fill="x")

    def update_live_calculations(*args):
        if var_custom_regex.get(): return 
        tok = ent_token.get().strip()
        if not tok:
            if not var_user_typed_folder.get(): 
                ent_fld.delete(0, tk.END)
            lbl_formula.config(text="[Enter scan keyword above]")
            return
            
        if not var_user_typed_folder.get():
            suggested_fld = tok.title() + ('s' if not tok.title().endswith('s') else '')
            ent_fld.delete(0, tk.END)
            ent_fld.insert(0, suggested_fld)
            
        lbl_formula.config(text=f"\\b{tok.lower()}(s)?\\b")

    # Map menu select inputs to trigger appropriate recalculation sequences
    cb_existing.bind("<<ComboboxSelected>>", lambda e: [var_user_typed_folder.set(True), lbl_hint.pack_forget(), ent_fld.delete(0, tk.END), ent_fld.insert(0, cb_existing.get()), update_live_calculations()])

    def toggle_custom_mode():
        if var_custom_regex.get():
            cb_existing.config(state="disabled")
            lbl_prefix.config(text="Custom RegEx Expression:")
            lbl_formula.config(text="[Direct Entry Mode Active]")
            ent_token.delete(0, tk.END)
            ent_token.insert(0, "\\b(hi)?hat(s)?\\b")
        else:
            cb_existing.config(state="readonly")
            lbl_prefix.config(text="When file name contains the word:")
            ent_token.delete(0, tk.END)
            ent_token.insert(0, "kick")
            var_user_typed_folder.set(False)
            update_live_calculations()

    tk.Checkbutton(f_toggle, text="Use Manual/Custom RegEx Formula Mode", variable=var_custom_regex, command=toggle_custom_mode, bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_muted"], selectcolor=gui_theme.THEME["bg_field"], font=("Segoe UI", 9, "italic")).pack(side="left")
    
    lbl_link = tk.Label(f_toggle, text="[Learn RegExr.com ↗]", font=("Segoe UI", 8, "underline"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["accent_neon"], cursor="hand2")
    lbl_link.pack(side="left", padx=15)
    lbl_link.bind("<Button-1>", lambda e: webbrowser.open("https://regexr.com"))

    ent_token.bind("<KeyRelease>", update_live_calculations)
    update_live_calculations()

    # Pass the populated elements to the terminal controller actions row
    build_builder_action_buttons(popup, ent_token, ent_fld, lbl_formula, var_custom_regex)

# Function 4: Parameter Commit Handlers and Action Control Stacks
def build_builder_action_buttons(popup, ent_token, ent_fld, lbl_formula, var_custom_regex):
    """Attaches validation controls and execution buttons to finalize active settings imports."""
    btn_panel = tk.Frame(popup, bg=gui_theme.THEME["bg_dark"])
    btn_panel.pack(fill="x", side="bottom", padx=20, pady=20)
    
    tk.Button(
        btn_panel, text="Cancel", font=("Segoe UI", 9, "bold"), 
        bg=gui_theme.THEME["bg_panel"], fg=gui_theme.THEME["fg_light"], 
        bd=0, padx=18, pady=6, command=popup.destroy
    ).pack(side="left")
    
    def save_new_rule_action():
        f = ent_fld.get().strip()
        p = ent_token.get().strip() if var_custom_regex.get() else lbl_formula.cget("text")
        
        # Shield parameters against empty variables or missing setup values
        if not f or not p or p.startswith("["): 
            return
            
        try: 
            re.compile(p)
        except re.error: 
            messagebox.showerror("Expression Fault", "Provided string values contain syntax profile errors.")
            return
            
        # Update configurations within global tracking libraries
        sorter_engine.DRUM_KEYWORDS[p] = f
        _sync_config_state(f"Appended sorting matrix rule for: {f}")
        popup.destroy()

    tk.Button(
        btn_panel, text="Save Sorting Rule", font=("Segoe UI", 9, "bold"), 
        bg=gui_theme.THEME["btn_execute"], fg="white", activebackground="#0e6b36", activeforeground="white", 
        bd=0, padx=18, pady=6, command=save_new_rule_action
    ).pack(side="right")

# tab_matrix.py - Piece 4: Graphical Layout Assembly & Action Bindings
def build(parent, status_label_ref):
    """Initializes the rule canvas ledger tables and maps component references cleanly."""
    global _drum_tree, _synth_tree, _status_label_ref
    _status_label_ref = status_label_ref
    
    style = ttk.Style()
    style.configure(
        "Treeview",
        background=gui_theme.THEME["bg_field"],      
        foreground=gui_theme.THEME["fg_light"],      
        fieldbackground=gui_theme.THEME["bg_field"], 
        rowheight=24,
        font=("Segoe UI", 9)
    )
    style.configure(
        "Treeview.Heading",
        background=gui_theme.THEME["bg_panel"],
        foreground=gui_theme.THEME["fg_light"],
        font=("Segoe UI", 9, "bold")
    )
    
    style.map("Treeview", 
        background=[("selected", gui_theme.THEME["hover_dark"]), ("active", gui_theme.THEME["bg_field"])], 
        foreground=[("selected", gui_theme.THEME["accent_neon"]), ("active", gui_theme.THEME["fg_light"])]
    )
    style.map("Treeview.Heading",
        background=[("active", gui_theme.THEME["hover_dark"]), ("pressed", gui_theme.THEME["bg_dark"])],
        foreground=[("active", gui_theme.THEME["accent_neon"]), ("pressed", gui_theme.THEME["fg_light"])]
    )

    master_workspace = tk.Frame(parent, bg=gui_theme.THEME["bg_dark"])
    master_workspace.pack(fill="both", expand=True, padx=15, pady=10)
    master_workspace.columnconfigure(0, weight=1)
    master_workspace.rowconfigure(0, weight=1)

    lists_frame = tk.Frame(master_workspace, bg=gui_theme.THEME["bg_dark"])
    lists_frame.grid(row=0, column=0, sticky="nsew")
    lists_frame.columnconfigure(0, weight=1)
    lists_frame.rowconfigure(0, weight=1) 
    lists_frame.rowconfigure(1, weight=1) 

    # SECTION 1: DRUM MATRIX GRID
    drum_section = tk.Frame(lists_frame, bg=gui_theme.THEME["bg_dark"])
    drum_section.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
    
    tk.Label(drum_section, text="Active Drum Sample Sorting Matrix Rules:", font=("Segoe UI", 9, "bold"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"]).pack(anchor="w", pady=(0, 4))
    
    drum_wrapper = ttk.Frame(drum_section)
    drum_wrapper.pack(fill="both", expand=True)
    drum_scroll = ttk.Scrollbar(drum_wrapper)
    drum_scroll.pack(side="right", fill="y")
    
    _drum_tree = ttk.Treeview(drum_wrapper, columns=('Regex Pattern', 'Target Destination Folder'), show='headings', style="Treeview", yscrollcommand=drum_scroll.set)
    _drum_tree.pack(fill="both", expand=True)
    drum_scroll.config(command=_drum_tree.yview)
    _drum_tree.heading('Regex Pattern', text='Search Pattern (RegEx)')
    _drum_tree.heading('Target Destination Folder', text='Target Drum Category Folder')
    _drum_tree.column('Regex Pattern', width=320, anchor='w')
    _drum_tree.column('Target Destination Folder', width=200, anchor='w')

    # SECTION 2: SYNTH & PRESET EXTENSIONS MATRIX GRID
    synth_section = tk.Frame(lists_frame, bg=gui_theme.THEME["bg_dark"])
    synth_section.grid(row=1, column=0, sticky="nsew", pady=(5, 0))
    
    tk.Label(synth_section, text="Active Synthesizer Preset & Live Device Rule Targets:", font=("Segoe UI", 9, "bold"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_light"]).pack(anchor="w", pady=(0, 4))
    
    synth_wrapper = ttk.Frame(synth_section)
    synth_wrapper.pack(fill="both", expand=True)
    synth_scroll = ttk.Scrollbar(synth_wrapper)
    synth_scroll.pack(side="right", fill="y")
    
    _synth_tree = ttk.Treeview(synth_wrapper, columns=('Extension Pattern', 'Target Destination Folder'), show='headings', style="Treeview", yscrollcommand=synth_scroll.set)
    _synth_tree.pack(fill="both", expand=True)
    synth_scroll.config(command=_synth_tree.yview)
    _synth_tree.heading('Extension Pattern', text='File Signature / Extension Target')
    _synth_tree.heading('Target Destination Folder', text='Target Sound Bank Folder')
    _synth_tree.column('Extension Pattern', width=320, anchor='w')
    _synth_tree.column('Target Destination Folder', width=200, anchor='w')

    # SECTION 3: CONTROL COLUMN PANEL
    action_panel = tk.Frame(master_workspace, bg=gui_theme.THEME["bg_dark"])
    action_panel.grid(row=0, column=1, sticky="ns", padx=(15, 0))
    
    def handle_rule_deletion():
        drum_sel = _drum_tree.selection()
        synth_sel = _synth_tree.selection() if _synth_tree else None
        
        if drum_sel:
            vals = _drum_tree.item(drum_sel, 'values')
            if vals and len(vals) > 0:
                pattern = vals[0]
                if pattern in sorter_engine.DRUM_KEYWORDS:
                    del sorter_engine.DRUM_KEYWORDS[pattern]
                    _sync_config_state(f"Deleted drum sorting rule for: {pattern}")
        elif synth_sel:
            vals = _synth_tree.item(synth_sel, 'values')
            if vals and len(vals) > 0:
                pattern = vals[0]
                if pattern in sorter_engine.SYNTH_EXTS:
                    del sorter_engine.SYNTH_EXTS[pattern]
                    _sync_config_state(f"Deleted preset rule for: {pattern}")
                elif pattern in sorter_engine.NATIVE_EXTS:
                    del sorter_engine.NATIVE_EXTS[pattern]
                    _sync_config_state(f"Deleted Live rack rule for: {pattern}")
        else:
            messagebox.showwarning("Selection Required", "Please select a rule row from either table category to delete.")

    # Core Action Layout Stack buttons
    tk.Button(action_panel, text="+ Add New Rule", bg=gui_theme.THEME["btn_execute"], fg="white", activebackground="#0e6b36", activeforeground="white", bd=0, font=("Segoe UI", 9, "bold"), width=16, height=2, command=lambda: launch_interactive_rule_builder(parent)).pack(anchor="n", pady=(24, 10))
    tk.Button(action_panel, text="❌ Delete Selected", bg=gui_theme.THEME["bg_panel"], fg=gui_theme.THEME["fg_light"], activebackground="#ff3333", activeforeground="white", bd=0, font=("Segoe UI", 9, "bold"), width=16, height=2, command=handle_rule_deletion).pack(anchor="n", pady=(0, 25))
    
    tk.Label(action_panel, text="Profile Management:", font=("Segoe UI", 8, "bold"), bg=gui_theme.THEME["bg_dark"], fg=gui_theme.THEME["fg_muted"]).pack(anchor="w", padx=5, pady=(15, 2))
    tk.Button(action_panel, text="💾 Export Profile", bg=gui_theme.THEME["bg_panel"], fg=gui_theme.THEME["fg_light"], activebackground=gui_theme.THEME["hover_dark"], activeforeground=gui_theme.THEME["accent_neon"], bd=1, relief="solid", font=("Segoe UI", 9), width=16, height=2, command=lambda: execute_profile_json_export(parent)).pack(anchor="n", pady=5)
    tk.Button(action_panel, text="📥 Import Profile", bg=gui_theme.THEME["bg_panel"], fg=gui_theme.THEME["fg_light"], activebackground=gui_theme.THEME["hover_dark"], activeforeground=gui_theme.THEME["accent_neon"], bd=1, relief="solid", font=("Segoe UI", 9), width=16, height=2, command=lambda: execute_profile_json_import(parent)).pack(anchor="n", pady=5)

    refresh_matrix_data()
