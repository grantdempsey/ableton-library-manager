# tab_organize.py - Piece 1: Framework Component Initialization & UI Grid Layout
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import stat
import platform
import threading
import zipfile
import datetime
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor

import gui_theme
import sorter_engine

class OrganizeTab(ttk.Frame):
    def __init__(self, parent, status_label_ref):
        """Initializes the master user library optimization panel with backup safeguards."""
        super().__init__(parent)
        self.status_lbl = status_label_ref
        
        self.library_dir_var = tk.StringVar(value="")
        self.backup_required_var = tk.BooleanVar(value=True)
        
        self.setup_ui_layout()
        self.after(50, self.prepopulate_user_library_path)

        # 🌟 FIXED INTERCEPT BIND: Checks event targets cleanly to suppress recursive sub-widget event bubbling
        self.bind("<Visibility>", lambda e: self.handle_tab_view_activation(e))

    def handle_tab_view_activation(self, event):
        """Triggers path cleaning constraints and runs the rules intercept scanning loop seamlessly on view."""
        # 🌟 CRITICAL SAFETY SHIELD: Only run if the event target matches this specific frame container widget
        if event.widget == self:
            self.strip_text_highlights()
            self.check_for_new_learned_rules_intercept()

    def setup_ui_layout(self):
        """Draws the single-path routing layout matched perfectly to the Import Dashboard geometry."""
        t = gui_theme.THEME

        # 1. Main Action Title Header
        header_lbl = ttk.Label(self, text="In-Place User Library Sorting & Structural Optimization", font=("Segoe UI", 12, "bold"))
        header_lbl.pack(anchor="w", padx=15, pady=15)

        # 2. TARGET DIRECTORY SELECTION BLOCK
        src_group = ttk.LabelFrame(self, text=" Target User Library (Folder to Scan and Organize In-Place) ")
        src_group.pack(fill="x", padx=15, pady=8, ipady=5)

        f_src_row = tk.Frame(src_group, bg=t["bg_dark"])
        f_src_row.pack(fill="x", padx=15, pady=8)

        self.ent_src = tk.Entry(f_src_row, font=("Consolas", 9), bg=t["bg_field"], fg=t["accent_gold"], bd=1, relief="solid", textvariable=self.library_dir_var, insertbackground=t["fg_light"])
        self.ent_src.pack(side="left", fill="x", expand=True, ipady=3)

        btn_browse_src = tk.Button(
            f_src_row, text="Browse...", font=("Segoe UI", 9),
            bg=t["bg_panel"], fg=t["fg_light"], activebackground=t["hover_dark"], activeforeground=t["accent_neon"],
            bd=1, relief="solid", padx=15, command=self.select_library_directory
        )
        btn_browse_src.pack(side="right", padx=(8, 0))

        # 3. DYNAMIC TELEMETRY NOTIFICATION BANNER CARD
        self.f_alert_box = tk.Frame(self, bg=t["bg_field"], bd=1, relief="solid", highlightbackground="#ff9900", highlightcolor="#ff9900")
        self.f_alert_box.pack(fill="x", padx=15, pady=10)
        
        self.lbl_alert = tk.Label(
            self.f_alert_box, 
            text="⚠️ WARNING: In-Place Restructuring Active! Your library folders will be organized inline. Backup recommended.",
            font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg="#ff9900", anchor="w", justify="left"
        )
        self.lbl_alert.pack(fill="x", padx=12, pady=8)

        # 4. UNIFIED DESKTOP ACTION CONTROL ROW
        f_actions_row = tk.Frame(self, bg=t["bg_dark"])
        f_actions_row.pack(fill="x", padx=15, pady=5)

        try:
            style = ttk.Style(self.master)
            style.configure("Dark.TCheckbutton", background=t["bg_dark"], foreground=t["fg_light"], font=("Segoe UI", 9, "bold"))
            style.map("Dark.TCheckbutton", background=[("active", t["bg_dark"]), ("pressed", t["bg_dark"])], foreground=[("active", t["accent_neon"])])
        except Exception:
            pass

        cb_wrapper = tk.Frame(f_actions_row, bg=t["bg_dark"])
        cb_wrapper.pack(side="left", fill="y")

        self.cb_backup = ttk.Checkbutton(
            cb_wrapper, 
            text="Create a compressed .zip backup before optimization",
            variable=self.backup_required_var, 
            style="Dark.TCheckbutton",
            command=self.trigger_instant_volume_safeguard_check
        )
        self.cb_backup.pack(side="left", padx=5, anchor="w")

        self.btn_execute = tk.Button(
            f_actions_row, text="⚡ Begin In-Place Optimization", font=("Segoe UI", 9, "bold"),
            bg=t["btn_execute"], fg="white", activebackground="#0e6b36", activeforeground="white",
            bd=0, padx=20, pady=6, command=self.execute_library_restructure
        )
        self.btn_execute.pack(side="right", padx=5)

# tab_organize.py - Piece 2: Automated Verification Loops & Safeguard Intercept Logic
        # 5. PROGRESS FEEDBACK BAR MATRIX
        f_progress_row = tk.Frame(self, bg=t["bg_dark"])
        f_progress_row.pack(fill="x", padx=15, pady=5)

        self.progress_bar = ttk.Progressbar(f_progress_row, orient="horizontal", mode="determinate")
        self.progress_bar.pack(fill="x", pady=(5, 2))

        # 6. ACTIVE PIPELINE PROCESSING CONSOLE OUTPUT
        console_frame = ttk.LabelFrame(self, text=" Active Structural Optimization In-Place Execution Log ")
        console_frame.pack(fill="both", expand=True, padx=15, pady=(10, 15))

        f_txt_wrapper = tk.Frame(console_frame, bg=t["bg_field"], bd=1, relief="solid")
        f_txt_wrapper.pack(fill="both", expand=True, padx=10, pady=10)

        scrollbar = ttk.Scrollbar(f_txt_wrapper, orient="vertical")
        scrollbar.pack(side="right", fill="y")

        self.console_log = tk.Text(
            f_txt_wrapper, wrap="none", state="disabled", font=("Consolas", 9),
            background=t["bg_field"], foreground=t["fg_light"], insertbackground=t["fg_light"],
            yscrollcommand=scrollbar.set, bd=0, highlightthickness=0
        )
        self.console_log.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        scrollbar.config(command=self.console_log.yview)
        
        self.focus_set()

    def check_for_new_learned_rules_intercept(self):
        """🌟 FIXED INTERCEPT: Explicitly reads local configuration script matrices directly to intercept unverified background rules."""
        config_filepath = getattr(sorter_engine, 'CONFIG_FILE', 'library_config.json')
        if not os.path.exists(config_filepath):
            return

        try:
            with open(config_filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            has_new_rules = data.get("NEW_RULES_PENDING", False)
            
            if has_new_rules:
                # Enforce style modifications cleanly on main loop parameters
                self.lbl_alert.config(
                    text="⚠️ SORTER ALERT: New automated naming patterns have been learned! Review them in the Rule Matrix tab or proceed.",
                    fg=gui_theme.THEME["accent_gold"]
                )
                self.f_alert_box.config(
                    highlightbackground=gui_theme.THEME["accent_gold"], 
                    highlightcolor=gui_theme.THEME["accent_gold"]
                )
            else:
                self.lbl_alert.config(
                    text="⚠️ WARNING: In-Place Restructuring Active! Your library folders will be organized inline. Backup recommended.",
                    fg="#ff9900"
                )
                self.f_alert_box.config(highlightbackground="#ff9900", highlightcolor="#ff9900")
        except Exception as e:
            print(f"DEBUG: Rule Intercept Error -> {str(e)}")

    def wipe_console_log(self):
        self.console_log.config(state="normal")
        self.console_log.delete("1.0", tk.END)
        self.console_log.config(state="disabled")

    def write_console_message(self, feedback_string):
        def append_operation():
            self.console_log.config(state="normal")
            self.console_log.insert(tk.END, f"{feedback_string}\n")
            self.console_log.see(tk.END)
            self.console_log.config(state="disabled")
        self.after(0, append_operation)

    def trigger_instant_volume_safeguard_check(self):
        target_path = self.library_dir_var.get().strip()
        if not target_path or not os.path.exists(target_path):
            return
        if self.backup_required_var.get():
            threading.Thread(target=self.evaluate_folder_mass_asynchronously, args=(target_path,), daemon=True).start()

    def strip_text_highlights(self):
        try:
            self.ent_src.selection_clear()
            self.ent_src.xview_moveto(0)
        except Exception:
            pass

    def select_library_directory(self):
        current_typed_path = self.library_dir_var.get().strip()
        starting_dir = current_typed_path if (current_typed_path and os.path.exists(current_typed_path)) else None
        
        selected = filedialog.askdirectory(title="Select Library Folder to Scan and Organize", initialdir=starting_dir)
        if selected:
            self.library_dir_var.set(os.path.normpath(selected))
            self.strip_text_highlights()
            self.trigger_instant_volume_safeguard_check()
            self.check_for_new_learned_rules_intercept()

    def prepopulate_user_library_path(self):
        user_home = os.path.expanduser("~")
        resolved_library_path = ""

        if platform.system() == "Windows":
            standard_doc_route = os.path.normpath(os.path.join(user_home, "Documents", "Ableton", "User Library"))
            onedrive_doc_route = os.path.normpath(os.path.join(user_home, "OneDrive", "Documents", "Ableton", "User Library"))
            if os.path.exists(standard_doc_route): resolved_library_path = standard_doc_route
            elif os.path.exists(onedrive_doc_route): resolved_library_path = onedrive_doc_route
            else: resolved_library_path = standard_doc_route
        elif platform.system() == "Darwin":
            mac_route = os.path.normpath(os.path.join(user_home, "Music", "Ableton", "User Library"))
            resolved_library_path = mac_route if os.path.exists(mac_route) else os.path.expanduser("~/Music/Ableton/User Library")

        self.library_dir_var.set(resolved_library_path)
        self.strip_text_highlights()
        
        # Fire rule checks natively right when the path Discovery loop maps successfully
        self.check_for_new_learned_rules_intercept()

# tab_organize.py - Piece 3: Thread-Safe Zip Archivers & Storage Mass Calculators
    def execute_library_restructure(self):
        target_path = self.library_dir_var.get().strip()
        if not target_path or not os.path.exists(target_path):
            messagebox.showerror("Routing Fault", "Please select a valid user library path before launching execution threads.")
            return

        self.btn_execute.config(state="disabled")
        self.cb_backup.config(state="disabled")
        self.progress_bar["value"] = 0
        self.wipe_console_log()

        if self.backup_required_var.get():
            self.write_console_message("Initializing pre-sorting environment security snapshots...")
            # 🌟 FIXED CROSS-PLATFORM CONSOLE ROUTING: Reports correct OS folder definitions live
            target_dest = "C:\\Ableton_Sort_Backups\\" if platform.system() == "Windows" else "~/Ableton_Sort_Backups/"
            self.write_console_message(f"Backup Destination Directory Target: {target_dest}")
            threading.Thread(target=self.run_safeguard_archiver_thread, args=(target_path,), daemon=True).start()
        else:
            self.kickoff_sorting_engine(target_path)

    def evaluate_folder_mass_asynchronously(self, target_path):
        total_bytes = 0
        local_files_count = 0
        is_massive_structure = False
        try:
            stack = [os.path.normpath(target_path)]
            while stack:
                current_dir = stack.pop()
                if "Ableton Folder Info" in current_dir: continue
                try: scandir_iterator = os.scandir(current_dir)
                except Exception: continue
                try:
                    for entry in scandir_iterator:
                        if entry.is_dir(follow_symlinks=False): stack.append(os.path.normpath(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            if not entry.name.startswith("._") and entry.name != "desktop.ini":
                                total_bytes += entry.stat().st_size
                                local_files_count += 1
                                if local_files_count > 15000 or total_bytes > (45 * 1024 ** 3):
                                    is_massive_structure = True
                                    break
                except Exception: pass
                if is_massive_structure: break
        except Exception: pass

        gigabytes_mass = total_bytes / (1024 ** 3)
        if gigabytes_mass > 50.0 or is_massive_structure:
            self.after(0, lambda: self.render_high_volume_warning_modal(gigabytes_mass, local_files_count, is_massive_structure))

    def render_high_volume_warning_modal(self, gigabytes_mass, local_files_count, is_massive_structure=False):
        try: master_window_container = self.nametowidget(".")
        except Exception:
            try:
                master_window_container = self.master
                while master_window_container.master is not None: master_window_container = master_window_container.master
            except Exception: master_window_container = self.winfo_toplevel()
        self.bell()
        messagebox.showwarning(
            "Large Library Detected",
            "Your User Library is exceptionally large!\n\n"
            "If you leave the backup checkbox enabled, copying and packaging your files into a zip archive will take a long time to complete.\n\n"
            "Please ensure you have adequate storage space available on your local drive before proceeding.",
            parent=master_window_container
        )

    def run_safeguard_archiver_thread(self, target_path):
        try:
            # 🌟 FIXED CROSS-PLATFORM PATH DIRECTIVE: Eradicates C:\ hardcoding defaults on non-Windows platforms
            if platform.system() == "Windows":
                backup_dir = os.path.normpath("C:/Ableton_Sort_Backups")
            else:
                backup_dir = os.path.normpath(os.path.expanduser("~/Ableton_Sort_Backups"))
                
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            archive_name = f"User_Library_Backup_{timestamp}.zip"
            archive_full_path = os.path.join(backup_dir, archive_name)

            self.write_console_message("Initializing high-velocity concurrent multi-threaded backup allocation...")
            local_files_to_pack = []
            skipped_stubs_count = 0
            
            stack = [os.path.normpath(target_path)]
            while stack:
                current_dir = stack.pop()
                if "Ableton Folder Info" in current_dir: continue
                try:
                    for entry in os.scandir(current_dir):
                        if entry.is_dir(follow_symlinks=False): stack.append(os.path.normpath(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            if entry.name.startswith("._") or entry.name == "desktop.ini": continue
                            full_filepath = os.path.normpath(entry.path)
                            try:
                                # 🌟 FIXED ATTRIBUTE SHIELD: Prevents Win32 attribute crashes when executed inside macOS
                                stat_result = os.stat(full_filepath)
                                if hasattr(stat_result, 'st_file_attributes'):
                                    raw_attrs = stat_result.st_file_attributes
                                    if (raw_attrs & 0x00400000) or (raw_attrs & 0x00001000):
                                        skipped_stubs_count += 1
                                        continue
                            except Exception: pass
                            local_files_to_pack.append(full_filepath)
                except Exception: pass

            total_assets_to_pack = len(local_files_to_pack)
            if total_assets_to_pack == 0:
                self.write_console_message("ℹ️ No locally cached assets detected in current path. Skipping backup framework.")
                self.after(0, lambda: self.kickoff_sorting_engine(target_path))
                return

            self.write_console_message(f" -> Index complete: {total_assets_to_pack} assets queued.")
            zip_write_lock = threading.Lock()
            
            with zipfile.ZipFile(archive_full_path, 'w', zipfile.ZIP_STORED, allowZip64=True) as zipf:
                stats_tracker = {"packed": 0, "skipped": 0}
                def process_single_backup_asset_worker(full_filepath):
                    relative_arcpath = os.path.relpath(full_filepath, target_path)
                    try:
                        with zip_write_lock: zipf.write(full_filepath, relative_arcpath)
                        stats_tracker["packed"] += 1
                    except Exception: stats_tracker["skipped"] += 1
                    current_processed = stats_tracker["packed"] + stats_tracker["skipped"]
                    if current_processed % 5000 == 0 or current_processed == total_assets_to_pack:
                        pct_complete = int((current_processed / total_assets_to_pack) * 100)
                        self.write_console_message(f" [Concurrent Backup]: Streamed -> {stats_tracker['packed']}/{total_assets_to_pack} files ({pct_complete}%)")

                with ThreadPoolExecutor(max_workers=4) as worker_pool:
                    worker_pool.map(process_single_backup_asset_worker, local_files_to_pack)

            self.after(0, lambda: self.write_backup_success_log(target_path, archive_full_path))
        except Exception as e:
            self.after(0, lambda: self.handle_backup_fault(target_path, str(e)))

# tab_organize.py - Piece 4: Parallel Sorting Engine Activation & Reporting Matrices
    def write_backup_success_log(self, target_path, archive_full_path):
        self.write_console_message(f"Archival package generated cleanly at location:\n -> {archive_full_path}")
        self.kickoff_sorting_engine(target_path)

    def handle_backup_fault(self, target_path, error_string):
        self.btn_execute.config(state="normal")
        self.cb_backup.config(state="normal")
        proceed_regardless = messagebox.askyesno("Safeguard Fault", f"Archive failed:\n{error_string}\n\nProceed without backup?", icon="warning")
        if proceed_regardless: self.kickoff_sorting_engine(target_path)

    def kickoff_sorting_engine(self, target_path):
        clean_target = os.path.normpath(target_path.strip())
        self.write_console_message("Firing parallel sorting network threads...")
        sorter = sorter_engine.ParallelLibrarySorter(src_path=clean_target, dest_path=clean_target, window_el=self, update_status_callback=self.write_console_message, done_callback=self.handle_execution_complete, copy_mode=False)
        sorter.start_parallel_sort()

    def handle_execution_complete(self, tracking_stats, copy_mode_flag):
        self.btn_execute.config(state="normal")
        self.cb_backup.config(state="normal")
        self.progress_bar["value"] = 100
        
        self.write_console_message("In-place database restructure operations resolved clean!")
        lines = []
        if tracking_stats.get("Native Live Racks (.adg, .amxd, .alc, .adv)", 0) > 0: lines.append(f"• Native Racks: {tracking_stats['Native Live Racks (.adg, .amxd, .alc, .adv)']}")
        if tracking_stats.get("Synth Presets & Wavetables (.fxp, .vital)", 0) > 0: lines.append(f"• Presets: {tracking_stats['Synth Presets & Wavetables (.fxp, .vital)']}")
        if tracking_stats.get("Loops Separated by BPM & Key", 0) > 0: lines.append(f"• Loops Sorted: {tracking_stats['Loops Separated by BPM & Key']}")
        if tracking_stats.get("One-Shots Grouped by Drum Type", 0) > 0: lines.append(f"• One-Shots Filed: {tracking_stats['One-Shots Grouped by Drum Type']}")
        summary = "\n".join(lines) if lines else "• State Coherent: All existing audio assets match target directory definitions."

        try: master_window_container = self.nametowidget(".")
        except Exception:
            try: master_window_container = self.master
            except Exception: master_window_container = self.winfo_toplevel()

        self.bell() 
        messagebox.showinfo("Structural Optimization Complete", f"In-Place Library operations finished successfully!\n\nSummary:\n{summary}", parent=master_window_container)
        if self.status_lbl: self.status_lbl.config(text=" Application Status: Structural allocation pass verified clean.", fg=gui_theme.THEME["accent_neon"])
