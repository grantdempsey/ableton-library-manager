# 🎹 ABLETON PRODUCTION ASSETS & SAMPLE STUDIO MANAGER v1.0.0

A high-performance, cross-platform dark-room desktop operations desk custom-built for intelligent categorization, sorting, and structural synchronization of audio production sample libraries, synthesizers, and hardware-level parameter profiling pipelines.

The architecture is explicitly designed to handle deep operating system path translations while replacing traditional manual button triggers with proactive, automated background execution routines.

---

## 🏛️ Cross-Platform Architecture & System Pillars

The application leverages Python’s native platform abstractions to deliver an identical dark-room experience on both **Windows** and **macOS**, removing the friction of manual configuration:

*   **Windows Environment:** Dynamically resolves system paths to target local `~\AppData\Roaming\Ableton\` and handles native library mappings inside your user `Documents` directory while intelligently insulating your library paths from intrusive OneDrive synchronization conflicts.
*   **macOS Environment:** Translates preference sweeps securely over to native storage hooks (`~/Library/Preferences/Ableton/` and `~/Music/Ableton/User Library/`) while abstracting system directory explorations natively through Finder processes using background terminal wrappers.

---

## 🎛️ Functional Design & Automated Action Layout

The master interface is split into specialized layout panes structured to execute an automated, end-to-end studio asset workflow:

1. **🚀 Home** - System splash matrix presenting core operational telemetry logs, environment diagnostic indicators, and the interface lock for **Smart Naming Pattern Learning Mode**.
2. **📥 Import Dashboard** - Multi-threaded asset ingestion deck designed to scan, pull, and distribute incoming audio media files from external source paths directly into your localized user library.
    *   **Automated Cross-Check:** Instantly fires a background verification scan on tab visibility or file selection, eliminating manual path verification checks.
    *   **Copy/Move Execution:** Move mode automatically deletes source records *only if they are verified duplicates* to preserve local storage safely.
3. **🗃️ Organize Library** - In-place structural analyzer targeting your active Ableton path structure for immediate inline optimization with zero reliance on temporary intermediate files.
    *   **Automated Volume Warning Guard:** Refactored lookahead check module which scales gracefully on large data sizes. It provides non-verbose, scannable warnings explicitly reminding users of backup duration footprints prior to restructuring execution.
    *   **User Library Backup Guard:** Integrates a thread-safe safety archive module to cleanly package your live `User Library` into a zip archive inside `C:\Ableton_Sort_Backups`.
    *   **Recursive Directory Flattening:** Aggressively scans nested redundancies deep within local paths and flattens folders into a single-tier hierarchy layout.
4. **📊 Rule Matrix** - Advanced dual-grid data sheet mapping dictionary taxonomies (Drums and Synthesizers/Presets) using custom RegEx compilation routing.
    *   **Rule Alerts:** Automatically appends a `NEW` layout tag whenever background Smart Filter regex loops generate fresh token rules on the fly.
    *   **Global Profile Portability:** Adds seamless **Export Profile** and **Import Workspace** buttons directly into your workspace action rows. This locks your rule files, extension filters, and exclusion arrays natively inside your OneDrive-synced User Library to survive total system crashes or hardware migrations.
5. **🚫 Folder Exclusions** - Registry mapping panel used to designate global file system storage patterns to skip completely (e.g., `vstplugins`, `eastwest`). Includes `No Key Info` as a hardcoded baseline safety shield to protect unpitched sample loop groups.
6. **⚙️ Experimental Options** - Hardware-level optimization dashboard designed to directly parse and write performance arguments to native Ableton preference files (`Options.txt`).
    *   **Automated Verification Framework:** Removes old, manual validation buttons entirely. Runs silent, hands-free validation sweeps natively on the tab's `<Visibility>` hook to report hardware telemetry (e.g., `Threads: 16`) onto your footer status bar in real-time.
    *   **Safe Pointer Actions:** The amber gold file path input bar configuration is locked to a read-only focus frame, preventing mouse pointer adjustments or code block highlight glitches.

---

## 🛠️ Build and Compilation Routines

The project includes an automated script wrapper (`build_app.py`) built on top of PyInstaller to compress all assets, modular panels, and icons down into a single standalone production binary executable module.

### Compilation Prerequisites
Ensure execution privileges are active for your shell context session before starting compilation routines:
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
```

### Fire the Compiler Pipeline Suite
```powershell
python build_app.py
```
*Note: Ensure any previous build instances are completely closed down before compiling to avoid background memory lock constraints (`PermissionError: [WinError 5]`).*

---

## 🎨 Visual Identity Specifications
- **Base Background:** `#1e1e1e` (Matted Charcoal Dark Room Profile)
- **Primary Execution Green:** `#107c41` (Unified Studio Emerald Button Accent)
- **Path Highlighting Color:** `#ffcc00` (High-Contrast Amber Gold Input Fields)
- **Warning Boundaries Color:** `#ff9900` (Distinct Warning Orange Typography)

---

## 🤝 Project Credits & Cohort Connections
*   **Core Engineering & Architecture:** Developed by Grant Dempsey.
*   **Vibe & Direction Inspiration:** Cultivated within the **Ancient Future Collective (AFC)** bass music production cohort led by Savej & friends.
