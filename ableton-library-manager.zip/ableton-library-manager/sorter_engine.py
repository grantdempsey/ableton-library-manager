# sorter_engine.py - Piece 1: Core Configuration Matrices & Global State Setup
import os
import sys
import json
import re
import zlib
import stat
import shutil
import subprocess
import threading
import xml.etree.ElementTree as ET
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

# Core Shared Platform State Configuration Mapping
CONFIG_FILE = "library_config.json"
AUDIO_EXTS = {'.wav', '.aif', '.aiff', '.flac', '.mp3', '.ogg', '.m4a'}

# Global lookup lists initialized as empty targets for GUI thread mapping hooks
BPM_RANGES = []
DRUM_KEYWORDS = {}
SYNTH_EXTS = {}
NATIVE_EXTS = {}
IGNORED_DIRECTORIES = ["Ableton Folder Info", "Backup", "Crash Recovery", "Factory Packages"]

def load_external_config():
    """Reads configuration matrices directly from disk to keep UI settings synced."""
    global BPM_RANGES, DRUM_KEYWORDS, SYNTH_EXTS, NATIVE_EXTS, IGNORED_DIRECTORIES
    if not os.path.exists(CONFIG_FILE):
        default_rules = {
            "BPM_RANGES": [[0, 99, "99 BPM and Below"], [100, 114, "100-114 BPM"], [115, 129, "115-129 BPM"], [130, 149, "130-149 BPM"], [150, 174, "150-174 BPM"], [175, 999, "175 BPM and Above"]],
            "DRUM_KEYWORDS": {
                "(?:^|[^a-zA-Z0-9])kick(?:s)?(?:$|[^a-zA-Z0-9])": "Kicks",
                "(?:^|[^a-zA-Z0-9])snare(?:s)?(?:$|[^a-zA-Z0-9])": "Snares",
                "(?:^|[^a-zA-Z0-9])(?:hi)?hat(?:s)?(?:$|[^a-zA-Z0-9])": "Hi-Hats",
                "(?:^|[^a-zA-Z0-9])open\\s*hat(?:$|[^a-zA-Z0-9])": "Hi-Hats",
                "(?:^|[^a-zA-Z0-9])closed\\s*hat(?:$|[^a-zA-Z0-9])": "Hi-Hats",
                "(?:^|[^a-zA-Z0-9])clap(?:s)?(?:$|[^a-zA-Z0-9])": "Claps",
                "(?:^|[^a-zA-Z0-9])rim(?:shot)?(?:$|[^a-zA-Z0-9])": "Snares",
                "(?:^|[^a-zA-Z0-9])tom(?:s)?(?:$|[^a-zA-Z0-9])": "Toms",
                "(?:^|[^a-zA-Z0-9])shaker(?:s)?(?:$|[^a-zA-Z0-9])": "Percussion/Shakers",
                "(?:^|[^a-zA-Z0-9])perc(?:ussion)?(?:$|[^a-zA-Z0-9])": "Percussion",
                "(?:^|[^a-zA-Z0-9])cym(?:bal)?(?:s)?(?:$|[^a-zA-Z0-9])": "Cymbals & Crashes",
                "(?:^|[^a-zA-Z0-9])808(?:s)?(?:$|[^a-zA-Z0-9])": "808 Sub Bass"
            },
            "SYNTH_EXTS": {".fxp": "Serum Presets", ".fxb": "Serum Banks"},
            "NATIVE_EXTS": {".adg": "Live Instrument Racks", ".amxd": "Max For Live Devices"},
            "IGNORED_DIRECTORIES": ["eastwest", "kontakt library", "spectrasonics", "steam", "vstplugins", "common files"]
        }
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_rules, f, indent=4)
            
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        try:
            user_rules = json.load(f)
            BPM_RANGES = [tuple(x) for x in user_rules.get("BPM_RANGES", [])]
            DRUM_KEYWORDS = user_rules.get("DRUM_KEYWORDS", {})
            SYNTH_EXTS = user_rules.get("SYNTH_EXTS", {})
            NATIVE_EXTS = user_rules.get("NATIVE_EXTS", {})
            IGNORED_DIRECTORIES = user_rules.get("IGNORED_DIRECTORIES", [])
            return user_rules
        except Exception:
            return {}

# Force load on module call so imports immediately populate global configuration states
load_external_config()

# sorter_engine.py - Piece 2: Class Initialization & Background Thread Routing
class ParallelLibrarySorter:
    def __init__(self, src_path, dest_path, window_el, update_status_callback, done_callback, copy_mode=False):
        """Initializes the multi-threaded file distribution and structural optimization engine."""
        self.src = os.path.normpath(src_path)
        self.dest = os.path.normpath(dest_path)
        self.window = window_el
        self.update_status = update_status_callback
        self.done_callback = done_callback
        self.copy_mode = copy_mode
        
        self.total_files = 0
        self.processed_files = 0
        self.raw_unmatched_tokens = []
        self.harvested_metadata = {}
        self.lock = threading.Lock()
        
        # Operational Analytics Register Ledger Matrix Tracking
        self.stats = {
            "Native Live Racks (.adg, .amxd, .alc, .adv)": 0, 
            "Synth Presets & Wavetables (.fxp, .vital)": 0, 
            "Loops Separated by BPM & Key": 0, 
            "One-Shots Grouped by Drum Type": 0, 
            "Skipped Duplicate Items": 0, 
            "Errors/Skipped Files": 0,
            "New Metadata Rules Learned & Written": 0
        }

    def start_parallel_sort(self):
        """Spins up background threading networks to execute operations without freezing the UI."""
        def background_execution_pipeline():
            # 🌟 TRACKING FLAG: Prevents the UI done_callback from being triggered multiple times
            callback_triggered = False
            
            try:
                if not self.copy_mode:
                    self.window.after(0, lambda: self.update_status("Executing background system sanity check..."))
                    ghost_presets = os.path.normpath(os.path.join(self.dest, "Presets", "Instruments", "Presets", "Instruments"))
                    one_shots_root = os.path.normpath(os.path.join(self.dest, "Samples", "One-Shots"))
                    
                    if os.path.exists(ghost_presets):
                        repair_script = f"""
                        if (Test-Path -LiteralPath '{ghost_presets}') {{
                            $Files = Get-ChildItem -LiteralPath '{ghost_presets}' -File -ErrorAction SilentlyContinue
                            foreach ($File in $Files) {{
                                Set-ItemProperty -LiteralPath $File.FullName -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
                                Move-Item -LiteralPath $File.FullName -Destination '{os.path.normpath(os.path.join(self.dest, "Live Instrument Racks"))}' -Force -Confirm:$false
                            }}
                            Remove-Item -LiteralPath '{ghost_presets}' -Recurse -Force -ErrorAction SilentlyContinue
                        }}
                        """
                        try:
                            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", repair_script],
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
                        except Exception: pass

                    if os.path.exists(one_shots_root):
                        try:
                            for folder in os.listdir(one_shots_root):
                                cat_path = os.path.join(one_shots_root, folder)
                                if os.path.isdir(cat_path):
                                    for target_ghost in ["Samples", "Loops"]:
                                        ghost_target_path = os.path.normpath(os.path.join(cat_path, target_ghost))
                                        if os.path.exists(ghost_target_path):
                                            dynamic_repair = f"""
                                            $GhostPath = '{ghost_target_path}'
                                            $FlatRoot = '{cat_path}'
                                            if (Test-Path -LiteralPath $GhostPath) {{
                                                $Files = Get-ChildItem -LiteralPath $GhostPath -Recurse -File -ErrorAction SilentlyContinue
                                                foreach ($File in $Files) {{
                                                    Set-ItemProperty -LiteralPath $File.FullName -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
                                                    Move-Item -LiteralPath $File.FullName -Destination $FlatRoot -Force -Confirm:$false
                                                }}
                                                Remove-Item -LiteralPath $GhostPath -Recurse -Force -ErrorAction SilentlyContinue
                                            }}
                                            """
                                            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", dynamic_repair],
                                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
                        except Exception: pass

                    try:
                        extracted_count = self.nuclear_powershell_flatten(self.src)
                        if extracted_count > 0:
                            self.stats["Native Live Racks (.adg, .amxd, .alc, .adv)"] += extracted_count
                    except Exception: pass

                self.window.after(0, lambda: self.update_status("Extracting Ableton browser tagging metadata..."))
                
                try: self.harvested_metadata = harvest_ableton_metadata(self.src)
                except Exception: self.harvested_metadata = {}

                self.window.after(0, lambda: self.update_status("Scanning directory layout safely..."))

                execution_manifest = []
                stack = [self.src]
                visited_paths = set()
                max_depth_guard = 0

                while stack:
                    max_depth_guard += 1
                    if max_depth_guard > 50000: 
                        break

                    current_dir = stack.pop()
                    current_norm = os.path.normpath(current_dir)

                    if current_norm in visited_paths or "Ableton Folder Info" in current_norm:
                        continue
                    visited_paths.add(current_norm)

                    relative_branch = current_norm.replace(self.src, "").strip(os.sep)
                    branch_segments = [seg for seg in relative_branch.split(os.sep) if seg.strip()]
                    if len(branch_segments) > 6:
                        continue

                    try:
                        for entry in os.scandir(current_norm):
                            if entry.is_symlink():
                                continue
                                
                            entry_norm = os.path.normpath(entry.path)
                            entry_lower = entry_norm.lower()

                            if entry.is_dir(follow_symlinks=False):
                                if any(ignore.lower() in entry_lower for ignore in IGNORED_DIRECTORIES if ignore.strip()):
                                    continue
                                    
                                stack.append(entry.path)
                            elif entry.is_file():
                                if entry.name == "library_config.json" or entry.name.endswith(".py") or entry.name.endswith(".pyw"):
                                    continue
                                execution_manifest.append((current_norm, entry.name))
                    except Exception:
                        pass

                self.total_files = len(execution_manifest)
                
                if self.total_files == 0 and self.stats["Native Live Racks (.adg, .amxd, .alc, .adv)"] == 0:
                    self.window.after(0, lambda: self.update_status("Scan complete. Library folders match rule taxonomies."))
                    if not callback_triggered:
                        callback_triggered = True
                        self.window.after(0, lambda: self.done_callback(self.stats, self.copy_mode))
                    return

                if self.total_files > 0:
                    with ThreadPoolExecutor(max_workers=4) as executor:
                        for item in execution_manifest:
                            executor.submit(self.process_single_file, *item)

                if self.raw_unmatched_tokens:
                    try:
                        if os.path.exists(CONFIG_FILE):
                            with open(CONFIG_FILE, 'r', encoding='utf-8') as f_obj:
                                disk_data = json.load(f_obj)
                            
                            token_counts = Counter(self.raw_unmatched_tokens)
                            updated_count = 0
                            
                            for (token, folder_dest), count in token_counts.items():
                                if count >= 5:
                                    generated_regex = f"\\\\b{token}\\\\w*\\\\b"
                                    if generated_regex not in disk_data.get("DRUM_KEYWORDS", {}):
                                        disk_data.setdefault("DRUM_KEYWORDS", {})[generated_regex] = folder_dest
                                        updated_count += 1
                                        
                            if updated_count > 0:
                                self.stats["New Metadata Rules Learned & Written"] = updated_count
                                with open(CONFIG_FILE, 'w', encoding='utf-8') as f_obj:
                                    json.dump(disk_data, f_obj, indent=4)
                                load_external_config()
                    except Exception: pass

                if not self.copy_mode:
                    self.window.after(0, lambda: self.update_status("Scrubbing empty leftover directories..."))
                    force_delete_empty_folders(self.src)
                    
                self.window.after(0, lambda: self.update_status("Task optimization complete!"))
                if not callback_triggered:
                    callback_triggered = True
                    self.window.after(0, lambda: self.done_callback(self.stats, self.copy_mode))
                
                # 🌟 CRITICAL FIX: Explicitly exit the background thread execution pipeline right here!
                # This completely blocks the function from sliding down into the generic 'except' handler.
                return
            
            except Exception as pipeline_err:
                self.window.after(0, lambda: self.update_status(f"Error: {str(pipeline_err)}"))
                if not callback_triggered:
                    callback_triggered = True
                    self.window.after(0, lambda: self.done_callback(self.stats, self.copy_mode))

        threading.Thread(target=background_execution_pipeline, daemon=True).start()

    def get_metadata_drum_target(self, filename):
        """Cross-references file data maps against internal metadata arrays."""
        fn_lower = filename.lower()
        if fn_lower in self.harvested_metadata:
            tags = self.harvested_metadata[fn_lower]
            tag_priority_map = [
                ('kick', 'Kicks'), ('snare', 'Snares'), ('hat', 'Hi-Hats'), 
                ('clap', 'Claps'), ('tom', 'Toms'), ('perc', 'Percussion'), 
                ('shaker', 'Percussion/Shakers'), ('vocal', 'Vocals & Chants'),
                ('vox', 'Vocals & Chants'), ('sub', '808 Sub Bass'), ('808', '808 Sub Bass'),
                ('bass', 'Synth Bass One-Shots'), ('pluck', 'Melodic & Synth One-Shots'),
                ('lead', 'Melodic & Synth One-Shots'), ('pad', 'Melodic & Synth One-Shots'),
                ('ambient', 'Cinematic & Ambience'), ('drone', 'Cinematic & Ambience'),
                ('texture', 'Cinematic & Ambience'), ('glitch', 'Glitches & Micro-Percussion'),
                ('fx', 'Sound FX'), ('effect', 'Sound FX')
            ]
            for target_key, folder_name in tag_priority_map:
                if any(target_key in t for t in tags): 
                    return folder_name, target_key
        return None, None

    def increment_stat_safe(self, key):
        """Thread-safe counter increments for runtime statistics logging."""
        with self.lock:
            if key in self.stats: 
                self.stats[key] += 1

    def process_single_file(self, root, f):
        """Processes categorization, namespacing adjustments, and moves files to target folders instantly."""
        global BPM_RANGES, DRUM_KEYWORDS, SYNTH_EXTS, NATIVE_EXTS
        
        try:
            f = str(f)
            f_lower = f.lower()
            root_lower = str(root).lower()
            
            # Extract the actual extension string from the tuple split
            ext_tuple = os.path.splitext(f_lower)
            ext = ext_tuple[1].strip() if len(ext_tuple) > 1 else ""
            
            s_path = os.path.normpath(os.path.join(root, f))
            target_dir = None
            stat_key = "Errors/Skipped Files"
            
            f_normalized = re.sub(r'[_#\-]', ' ', f_lower)
            
            normalized_root = s_path.replace(self.src, "").strip(os.sep)
            path_segments = [seg.lower() for seg in normalized_root.split(os.sep) if seg.strip()]

            # 🌟 INFINITE LOOP INCEPTION BLOCKER: 
            # If the source folder structure is already recursively looping, escape immediately!
            if path_segments.count("samples") > 1 or path_segments.count("loops") > 1 or path_segments.count("midi") > 1 or path_segments.count("percussion") > 1:
                if not self.copy_mode:
                    try: os.remove(s_path)
                    except Exception: pass
                return

            # 🌟 PARENT-FOLDER SAFETY GUARD:
            # If the file is ALREADY sitting inside one of your top-level organized system blocks,
            # DO NOT parse its folder name for keywords. This completely stops Percussion\Percussion loops.
            is_already_sorted = False
            if path_segments:
                top_level_folder = path_segments[0]
                if top_level_folder in ["percussion", "midi", "serum presets", "live instrument racks", "max for live devices"]:
                    is_already_sorted = True
                elif top_level_folder == "samples" and len(path_segments) > 1 and path_segments[1] in ["one-shots", "loops"]:
                    is_already_sorted = True

            # 1. KEYWORD GRID OVERRIDE PATTERN SCAN
            grid_matched_folder = None
            if not is_already_sorted:
                for pattern, folder in DRUM_KEYWORDS.items():
                    if re.search(pattern, f_normalized) or re.search(pattern, f_lower) or re.search(pattern, root_lower):
                        grid_matched_folder = folder
                        break
                    
            if grid_matched_folder:
                if "/" in grid_matched_folder or "\\" in grid_matched_folder:
                    target_dir = os.path.join(self.dest, *re.split(r'[/\\]', grid_matched_folder))
                else:
                    if ext in NATIVE_EXTS: 
                        target_dir = os.path.join(self.dest, NATIVE_EXTS.get(ext, "Live Instrument Racks"))
                    elif ext in SYNTH_EXTS: 
                        target_dir = os.path.join(self.dest, SYNTH_EXTS.get(ext, "Serum Presets"))
                    elif ext == '.mid' or ext == '.midi':
                        target_dir = os.path.join(self.dest, "Midi")
                    else: 
                        if grid_matched_folder.lower() in ["percussion", "shakers", "congas", "bongo"]:
                            target_dir = os.path.join(self.dest, "Percussion", "Shakers")
                        else:
                            target_dir = os.path.join(self.dest, "Samples", "One-Shots", grid_matched_folder)
                
                if ext in NATIVE_EXTS: stat_key = "Native Live Racks (.adg, .amxd, .alc, .adv)"
                elif ext in SYNTH_EXTS: stat_key = "Synth Presets & Wavetables (.fxp, .vital)"
                elif ext == '.mid' or ext == '.midi': stat_key = "Loops Separated by BPM & Key"
                else: stat_key = "One-Shots Grouped by Drum Type"

            # 2. ABLETON METADATA AUTO-TAG CHECK FALLBACK
            if not target_dir and ext in AUDIO_EXTS:
                meta_drum_folder, raw_tag = self.get_metadata_drum_target(f)
                if meta_drum_folder:
                    if meta_drum_folder.lower() in ["percussion", "shakers"]:
                        target_dir = os.path.join(self.dest, "Percussion", "Shakers")
                    else:
                        target_dir = os.path.join(self.dest, "Samples", "One-Shots", meta_drum_folder)
                    stat_key = "One-Shots Grouped by Drum Type"
                    
                    try:
                        base_name_str = os.path.splitext(f_lower)[0]
                        base_clean = re.sub(r'[\d_\-]', ' ', base_name_str)
                        tokens = [t for t in base_clean.split() if len(t) >= 3]
                        if tokens:
                            with self.lock:
                                for token in tokens:
                                    self.raw_unmatched_tokens.append((token, meta_drum_folder))
                    except Exception:
                        pass

            # 3. CONTEXT-BASED GENERIC FALLBACK ROUTING
            if not target_dir:
                if ext in NATIVE_EXTS:
                    target_dir = os.path.join(self.dest, NATIVE_EXTS.get(ext, "Live Instrument Racks"))
                    stat_key = "Native Live Racks (.adg, .amxd, .alc, .adv)"
                elif ext in SYNTH_EXTS:
                    target_dir = os.path.join(self.dest, SYNTH_EXTS.get(ext, "Serum Presets"))
                    stat_key = "Synth Presets & Wavetables (.fxp, .vital)"
                elif ext == '.mid' or ext == '.midi':
                    target_dir = os.path.join(self.dest, "Midi")
                    stat_key = "Loops Separated by BPM & Key"
                elif ext in AUDIO_EXTS:
                    is_meta_loop = f_lower in self.harvested_metadata and any('loop' in t for t in self.harvested_metadata[f_lower])
                    has_bpm = re.search(r'\b\d{2,3}\s*(bpm|BPM)\b', f_normalized)
                    is_text_loop = any(k in f_normalized or k in root_lower for k in ['loop', 'fill', 'roll', 'groove']) or has_bpm
                    
                    if is_meta_loop or is_text_loop:
                        match = re.search(r'\b(\d{2,3})\s*(?:bpm|BPM|_bpm|_BPM)\b', f_lower)
                        if not match: match = re.search(r'(?<!\w)(\d{2,3})(?!\w)', f_lower)
                        
                        bpm_folder = "Unsorted Tempos"
                        if match:
                            try:
                                p_bpm = int(match.group(1))
                                if 40 <= p_bpm <= 250:
                                    for low, high, folder_name in BPM_RANGES:
                                        if low <= p_bpm <= high:
                                            bpm_folder = folder_name
                                            break
                            except ValueError: pass
                        
                        key_match = re.search(r'\b([a-gA-G][#b]?m(in)?|[a-gA-G][#b]?(maj)?|\d{1,2}[a-dB-D])\b', f)
                        musical_key = key_match.group(1).upper() if key_match else "No Key Info"
                        
                        target_dir = os.path.join(self.dest, "Samples", "Loops", bpm_folder, musical_key)
                        stat_key = "Loops Separated by BPM & Key"
                    else:
                        target_dir = os.path.join(self.dest, "Samples", "One-Shots", "Other One-Shots")
                        stat_key = "One-Shots Grouped by Drum Type"
                elif "presets" in root_lower or "instruments" in root_lower:
                    target_dir = os.path.join(self.dest, "Live Instrument Racks")
                    stat_key = "Native Live Racks (.adg, .amxd, .alc, .adv)"
                else:
                    return

            target_dir = os.path.normpath(target_dir)
            d_path = os.path.normpath(os.path.join(target_dir, f))
            
            if os.path.normpath(root) == target_dir: return

            os.makedirs(target_dir, exist_ok=True)
            try: os.chmod(s_path, stat.S_IWRITE)
            except Exception: pass
            
            if os.path.exists(d_path):
                s_crc = calculate_crc32(s_path)
                d_crc = calculate_crc32(d_path)
                if s_crc is not None and s_crc == d_crc:
                    self.increment_stat_safe("Skipped Duplicate Items")
                    if not self.copy_mode:
                        try: os.remove(s_path)
                        except Exception: pass
                    return
                else:
                    counter = 1
                    base_name, file_ext = os.path.splitext(f)
                    while os.path.exists(d_path):
                        d_path = os.path.normpath(os.path.join(target_dir, f"{base_name}_{counter}{file_ext}"))
                        counter += 1

            current_processed = self.processed_files + 1
            if current_processed % 25 == 0 or current_processed == self.total_files:
                self.window.after(0, lambda: self.update_status(f"Filing Asset ({current_processed}/{self.total_files}) -> {f}"))
            
            if not self.copy_mode:
                os.replace(s_path, d_path)
            else:
                shutil.copy2(s_path, d_path)
            
            self.increment_stat_safe(stat_key)
        except Exception:
            self.increment_stat_safe("Errors/Skipped Files")
        finally:
            with self.lock: 
                self.processed_files += 1

# sorter_engine.py - Piece 7: Low-Level Data Validation & XML Tag Harvesters
    def nuclear_powershell_flatten(self, user_library_path):
        """Bypasses deep Windows directory ceilings by flattening nested items via PowerShell."""
        user_library_path = os.path.normpath(user_library_path)
        nested_target = os.path.join(user_library_path, "Presets", "Instruments", "Presets", "Instruments")
        target_root = os.path.join(user_library_path, "Live Instrument Racks")
        prune_target = os.path.join(user_library_path, "Presets", "Instruments", "Presets")
        
        if not os.path.exists(nested_target): return 0

        ps_script = f"""
        $NestedPath = '{nested_target}'
        $TargetRoot = '{target_root}'
        $PruneTarget = '{prune_target}'
        if (-not (Test-Path -LiteralPath $TargetRoot)) {{
            New-Item -ItemType Directory -Path $TargetRoot -Force | Out-Null
        }}
        if (Test-Path -LiteralPath $NestedPath) {{
            $Files = Get-ChildItem -LiteralPath $NestedPath -File -ErrorAction SilentlyContinue
            foreach ($File in $Files) {{
                Set-ItemProperty -LiteralPath $File.FullName -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
                Move-Item -LiteralPath $File.FullName -Destination $TargetRoot -Force -Confirm:$false
            }}
        }}
        if (Test-Path -LiteralPath $PruneTarget) {{
            Remove-Item -LiteralPath $PruneTarget -Recurse -Force -ErrorAction SilentlyContinue
        }}
        """
        try:
            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
            return len(os.listdir(target_root)) if os.path.exists(target_root) else 0
        except Exception: return 0

    def force_delete_empty_folders(self, target_path):
        """Class method wrapper hook that allows test runners to cleanly trigger 
        the structural folder scrub utility across targeted path strings.
        """
        return force_delete_empty_folders(target_path)


# ---------------------------------------------------------------------------------
# Low-Level Disk IO System Utilities (Sitting cleanly outside class scope)
# ---------------------------------------------------------------------------------

def calculate_crc32(filepath):
    """Calculates data checksums to prevent filing duplicate audio assets."""
    try:
        with open(filepath, 'rb') as f:
            crc = 0
            while chunk := f.read(65536):
                crc = zlib.crc32(chunk, crc)
            return crc & 0xFFFFFFFF
    except Exception: return None

def force_delete_empty_folders(root_dir):
    """Recursively sweeps and clears out dead paths from storage blocks."""
    count = 0
    for root, dirs, _ in os.walk(root_dir, topdown=False):
        for d in dirs:
            dir_path = os.path.join(root, d)
            try:
                os.chmod(dir_path, stat.S_IWRITE)
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)
                    count += 1
            except Exception: pass
    return count

def harvest_ableton_metadata(src_directory):
    """Parses xmp.cfg metadata blocks to extract native project tags."""
    metadata_map = {}
    for root, dirs, files in os.walk(src_directory):
        if os.path.basename(root) == "Ableton Folder Info":
            cfg_path = os.path.join(root, "xmp.cfg")
            if not os.path.exists(cfg_path): continue
            try:
                tree = ET.parse(cfg_path)
                xml_root = tree.getroot()
                for content_tag in xml_root.findall('.//ContentExtId'):
                    filename = content_tag.get('Name')
                    if not filename: continue
                    tags_list = []
                    for tag_entry in content_tag.findall('.//Tag'):
                        tag_id = tag_entry.get('Id')
                        if tag_id: tags_list.append(tag_id.split('/')[-1].lower())
                    if tags_list: metadata_map[filename.lower()] = tags_list
            except Exception: pass
    return metadata_map
