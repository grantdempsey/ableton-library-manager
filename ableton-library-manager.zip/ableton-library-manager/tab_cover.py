# tab_cover.py - Ableton Production Assets & Sample Studio Manager Unified Home Dashboard
import tkinter as tk
from tkinter import ttk
import gui_theme

def build(parent_frame):
    """Assembles the primary welcome splash entry card layer layout matrix with completely cohesive titles."""
    t = gui_theme.THEME

    # 1. Main Background Workspace Framing Card
    f_center_box = tk.Frame(parent_frame, bg=t["bg_dark"])
    f_center_box.place(relx=0.5, rely=0.45, anchor="center")

    # 2. Main Title Branding Label
    lbl_brand = tk.Label(
        f_center_box, 
        text="🎧  ABLETON PRODUCTION ASSETS & SAMPLE STUDIO MANAGER", 
        font=("Segoe UI", 14, "bold"), 
        bg=t["bg_dark"], 
        fg=t["accent_neon"]
    )
    lbl_brand.pack(pady=(0, 5))

    # 3. System Deployment Engine Version Label
    lbl_version = tk.Label(
        f_center_box, 
        text="Production Suite System Deployment Engine • Version 1.0", 
        font=("Segoe UI", 9, "italic"), 
        bg=t["bg_dark"], 
        fg=t["fg_muted"]
    )
    lbl_version.pack(pady=(0, 25))

    # 4. PRIMARY SYSTEM FEATURE EXPLANATION BLOCK
    f_info_card = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_info_card.pack(fill="x", padx=10, ipady=12)

    lbl_desc_title = tk.Label(f_info_card, text="What this tool does:", font=("Segoe UI", 10, "bold"), bg=t["bg_field"], fg=t["fg_light"])
    lbl_desc_title.pack(anchor="w", padx=15, pady=(8, 2))

    lbl_desc_body = tk.Label(
        f_info_card,
        text="This utility automatically scans your designated production asset folders, extracts browser metadata\n"
             "tags directly, and dynamically restructures your files into neat, structured subfolders sorted by type\n"
             "(like Kicks, Snares, or Melodic Loops) while cleaning up empty directory trees completely.",
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_desc_body.pack(anchor="w", padx=15, pady=(0, 15))

    lbl_guide_title = tk.Label(f_info_card, text="Quick Start Guide:", font=("Segoe UI", 10, "bold"), bg=t["bg_field"], fg=t["fg_light"])
    lbl_guide_title.pack(anchor="w", padx=15, pady=(0, 2))

    lbl_guide_body = tk.Label(
        f_info_card,
        text="• Import Dashboard: Safely extract and sort external sound vendor packages into your library path roots.\n"
             "• Organize Library: Perform immediate in-place structural optimization updates to your active folders.\n"
             "• Rule Matrix: Manually review or create customized keyword regex sorting rule bindings.",
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_guide_body.pack(anchor="w", padx=15, pady=(0, 8))

    # 5. SMART LEARNING CONFIGURATION SUB-FRAME CARD
    f_learning_card = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_learning_card.pack(fill="x", padx=10, pady=15, ipady=10)

    lbl_smart_title = tk.Label(f_learning_card, text="🧠  Smart Learning Mode", font=("Segoe UI", 10, "bold"), bg=t["bg_field"], fg=t["accent_neon"])
    lbl_smart_title.pack(anchor="w", padx=15, pady=(8, 4))

    # 🌟 CRITICAL MEMORY TETHER FIX: Bind the Boolean state property directly to parent_frame 
    # to protect it from Python garbage collection sweeps, and hardcode value=True.
    parent_frame.smart_learning_enabled = tk.BooleanVar(value=True)
    
    cb_smart = tk.Checkbutton(
        f_learning_card, text="Enable Smart Naming Pattern Learning", 
        variable=parent_frame.smart_learning_enabled,
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_light"], selectcolor=t["bg_dark"],
        activebackground=t["bg_field"], activeforeground=t["accent_neon"], bd=0
    )
    cb_smart.pack(anchor="w", padx=12)

    lbl_smart_hint = tk.Label(
        f_learning_card,
        text="When checked, the backend engine monitors local organization trends. If you sort a specific keyword\n"
             "into an identically named target folder 5+ times, it creates a custom sorting matrix rule automatically.",
        font=("Segoe UI", 8, "italic"), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_smart_hint.pack(anchor="w", padx=15, pady=(4, 4))

    # 6. STUDIO ENVIRONMENT FOOTNOTE BAR
    f_footnote = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_footnote.pack(fill="x", padx=10, ipady=4)

    lbl_cohort = tk.Label(
        f_footnote, 
        text="📁  Mentorship Cohort Support • Created by Grant Dempsey\n"
             "Community: Ancient Future Collective (AFC) Production Pipeline",
        font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg=t["accent_gold"], justify="center"
    )
    lbl_cohort.pack(fill="x", pady=6)

    # 7. Core Interface Operational Navigation Hint Text
    lbl_footer_hint = tk.Label(
        f_center_box, text="Flip tabs above to navigate different production asset toolsets...",
        font=("Segoe UI", 8, "italic"), bg=t["bg_dark"], fg=t["fg_muted"]
    )
    lbl_footer_hint.pack(pady=(15, 0))
