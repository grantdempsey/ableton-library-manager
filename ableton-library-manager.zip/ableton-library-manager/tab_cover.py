# tab_cover.py - Ableton Production Assets & Sample Studio Manager Unified Home Dashboard
import tkinter as tk
from tkinter import ttk
import gui_theme

def build(parent_frame):
    """Assembles the primary welcome splash screen layout with clean, punchy copy."""
    t = gui_theme.THEME

    # 1. Main Background Container
    f_center_box = tk.Frame(parent_frame, bg=t["bg_dark"])
    f_center_box.place(relx=0.5, rely=0.45, anchor="center")

    # 2. Main Header Branding
    lbl_brand = tk.Label(
        f_center_box, 
        text="🎧  ABLETON PRODUCTION ASSETS & SAMPLE STUDIO MANAGER", 
        font=("Segoe UI", 13, "bold"), 
        bg=t["bg_dark"], 
        fg=t["accent_neon"]
    )
    lbl_brand.pack(pady=(0, 5))

    # 3. System Deployment Subtitle
    lbl_version = tk.Label(
        f_center_box, 
        text="Production Suite System Deployment Engine • Version 1.0", 
        font=("Segoe UI", 9, "italic"), 
        bg=t["bg_dark"], 
        fg=t["fg_muted"]
    )
    lbl_version.pack(pady=(0, 20))

    # 4. PRIMARY SYSTEM FEATURE EXPLANATION CARD
    f_info_card = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_info_card.pack(fill="x", padx=10, ipady=10)

    tk.Label(f_info_card, text="What this tool does:", font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg=t["fg_light"]).pack(anchor="w", padx=15, pady=(6, 2))
    
    lbl_desc_body = tk.Label(
        f_info_card,
        text="• Scans production folders and extracts Ableton browser tags automatically.\n"
             "• Restructures audio assets cleanly into categorized subfolders (Kicks, Snares, Loops).\n"
             "• Purges redundant empty directory trees from local storage inline.",
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_desc_body.pack(anchor="w", padx=15, pady=(0, 12))

    tk.Label(f_info_card, text="Quick Start Guide:", font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg=t["fg_light"]).pack(anchor="w", padx=15, pady=(0, 2))

    lbl_guide_body = tk.Label(
        f_info_card,
        text="• Import Dashboard: Extract and filter sample pack contents directly into library tracks.\n"
             "• Organize Library: Execute immediate in-place sorting optimizations to active folders.\n"
             "• Rule Matrix: Review, update, or build custom keyword regex processing rules.",
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_guide_body.pack(anchor="w", padx=15, pady=(0, 6))

    # 5. SMART LEARNING CONFIGURATION CARD
    f_learning_card = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_learning_card.pack(fill="x", padx=10, pady=12, ipady=8)

    tk.Label(f_learning_card, text="🧠  Smart Learning Mode", font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg=t["accent_neon"]).pack(anchor="w", padx=15, pady=(6, 2))

    parent_frame.smart_learning_enabled = tk.BooleanVar(value=True)
    cb_smart = tk.Checkbutton(
        f_learning_card, text="Enable Smart Naming Pattern Learning", 
        variable=parent_frame.smart_learning_enabled,
        font=("Segoe UI", 9), bg=t["bg_field"], fg=t["fg_light"], selectcolor=t["bg_dark"],
        activebackground=t["bg_field"], activeforeground=t["accent_neon"], bd=0
    )
    cb_smart.pack(anchor="w", padx=12)

    lbl_smart_hint = tk.Label(
        f_learning_card,
        text="Monitors your directory habits. If you sort a keyword into a target folder 5+ times,\n"
             "the application automatically creates a custom regex rule to handle it going forward.",
        font=("Segoe UI", 8, "italic"), bg=t["bg_field"], fg=t["fg_muted"], justify="left"
    )
    lbl_smart_hint.pack(anchor="w", padx=15, pady=(4, 4))

    # 6. STUDIO ENVIRONMENT COMMUNITY FOOTNOTE
    f_footnote = tk.Frame(f_center_box, bg=t["bg_field"], bd=1, relief="solid", highlightbackground=t["bg_panel"], highlightcolor=t["bg_panel"])
    f_footnote.pack(fill="x", padx=10, ipady=2)

    lbl_cohort = tk.Label(
        f_footnote, 
        text="📁  Mentorship Cohort Support • Created by Grant Dempsey\n"
             "Community: Ancient Future Collective (AFC) Production Pipeline",
        font=("Segoe UI", 9, "bold"), bg=t["bg_field"], fg=t["accent_gold"], justify="center"
    )
    lbl_cohort.pack(fill="x", pady=4)

    # 7. Navigation Footer Prompt
    tk.Label(
        f_center_box, text="Flip tabs above to navigate different production asset toolsets...",
        font=("Segoe UI", 8, "italic"), bg=t["bg_dark"], fg=t["fg_muted"]
    ).pack(pady=(12, 0))
