@echo off
start pythonw gui.pyw
